struct stat;
struct rtcdate;

#define HISTORY_MAX 16
#define PROCSNAP_MAX 64

enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

enum procevent {
	PROCEVENT_CREATE = 1,
	PROCEVENT_FORK,
	PROCEVENT_EXEC,
	PROCEVENT_SLEEP,
	PROCEVENT_WAKEUP,
	PROCEVENT_EXIT,
	PROCEVENT_KILL,
};

struct proceventrec {
	int seq;
	int type;
	int info;
};

struct procsnap {
	int pid;
	int ppid;
	int state;
	char name[16];
};

// modified: user-visible process info structure for getprocinfo.
struct procinfo {
	int pid;
	int ppid;
	char name[16];
	int state;
	uint sz;
	uint ctime;
	uint total_ticks;
	uint last_cpu_tick;
	uint descendant_ticks;
	uint total_cpu_ticks;
};

// modified: user-visible system info structure for getsysinfo.
struct sysinfo {
	int num_active_proc;
	int num_runnable_proc;
	int num_sleeping_proc;
	uint uptime;
};

// system calls
int fork(void);
int exit(void) __attribute__((noreturn));
int wait(void);
int pipe(int*);
int write(int, const void*, int);
int read(int, void*, int);
int close(int);
int kill(int);
int exec(char*, char**);
int open(const char*, int);
int mknod(const char*, short, short);
int unlink(const char*);
int fstat(int fd, struct stat*);
int link(const char*, const char*);
int mkdir(const char*);
int chdir(const char*);
int dup(int);
int getpid(void);
char* sbrk(int);
int sleep(int);
int uptime(void);
int history(int, struct proceventrec*, int);
int ps(struct procsnap*, int);
// modified: feature-1 system call prototypes.
int getprocinfo(int, struct procinfo*);
int getsysinfo(struct sysinfo*);

// ulib.c
int stat(const char*, struct stat*);
char* strcpy(char*, const char*);
void *memmove(void*, const void*, int);
char* strchr(const char*, char c);
int strcmp(const char*, const char*);
void printf(int, const char*, ...);
char* gets(char*, int max);
uint strlen(const char*);
void* memset(void*, int, uint);
void* malloc(uint);
void free(void*);
int atoi(const char*);

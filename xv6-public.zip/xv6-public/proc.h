// Per-CPU state
struct cpu {
  uchar apicid;                // Local APIC ID
  struct context *scheduler;   // swtch() here to enter scheduler
  struct taskstate ts;         // Used by x86 to find stack for interrupt
  struct segdesc gdt[NSEGS];   // x86 global descriptor table
  volatile uint started;       // Has the CPU started?
  int ncli;                    // Depth of pushcli nesting.
  int intena;                  // Were interrupts enabled before pushcli?
  struct proc *proc;           // The process running on this cpu or null
};

extern struct cpu cpus[NCPU];
extern int ncpu;

//PAGEBREAK: 17
// Saved registers for kernel context switches.
// Don't need to save all the segment registers (%cs, etc),
// because they are constant across kernel contexts.
// Don't need to save %eax, %ecx, %edx, because the
// x86 convention is that the caller has saved them.
// Contexts are stored at the bottom of the stack they
// describe; the stack pointer is the address of the context.
// The layout of the context matches the layout of the stack in swtch.S
// at the "Switch stacks" comment. Switch doesn't save eip explicitly,
// but it is on the stack and allocproc() manipulates it.
struct context {
  uint edi;
  uint esi;
  uint ebx;
  uint ebp;
  uint eip;
};

enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

#define HISTORY_MAX 16
#define PROCSNAP_MAX 64

enum procevent {
  PROCEVENT_CREATE = 1,
  PROCEVENT_FORK,
  PROCEVENT_EXEC,
  PROCEVENT_SLEEP,
  PROCEVENT_WAKEUP,
  PROCEVENT_EXIT,
  PROCEVENT_KILL,
};

struct proceventrec {
  int seq;
  int type;
  int info;
};

struct procsnap {
  int pid;
  int ppid;
  int state;
  char name[16];
};

// modified: process information structure for feature 1 getprocinfo syscall.
struct procinfo {
  int pid;
  int ppid;
  char name[16];
  int state;
  uint sz;
  uint ctime;             // Creation time in ticks
  uint total_ticks;       // Total execution time in ticks
  uint last_cpu_tick;     // Tick timestamp when last scheduled/active
  uint descendant_ticks;  // CPU ticks consumed by descendants
  uint total_cpu_ticks;   // Sum of process ticks and descendant ticks
};

// modified: system information structure for feature 1 getsysinfo syscall.
struct sysinfo {
  int num_active_proc;    // Total active processes (non-UNUSED)
  int num_runnable_proc;  // Number of runnable/running processes
  int num_sleeping_proc;  // Number of sleeping processes
  uint uptime;            // System uptime in ticks
};

// Per-process state
struct proc {
  uint sz;                     // Size of process memory (bytes)
  pde_t* pgdir;                // Page table
  char *kstack;                // Bottom of kernel stack for this process
  enum procstate state;        // Process state
  int pid;                     // Process ID
  struct proc *parent;         // Parent process
  struct trapframe *tf;        // Trap frame for current syscall
  struct context *context;     // swtch() here to run process
  void *chan;                  // If non-zero, sleeping on chan
  int killed;                  // If non-zero, have been killed
  struct file *ofile[NOFILE];  // Open files
  struct inode *cwd;           // Current directory
  char name[16];               // Process name (debugging)
  // modified: bounded per-process event log for feature 2 history queries.
  struct proceventrec history[HISTORY_MAX];
  int history_head;
  int history_count;
  // modified: cpu runtime and lifecycle tracking fields for feature 1.
  uint ctime;                  // Process creation timestamp (ticks)
  uint total_ticks;            // Total CPU ticks consumed
  uint last_cpu_tick;          // Last CPU tick timestamp
  uint descendant_ticks;       // Accumulated CPU ticks from reaped descendants
};

// Process memory is laid out contiguously, low addresses first:
//   text
//   original data and bss
//   fixed-size stack
//   expandable heap

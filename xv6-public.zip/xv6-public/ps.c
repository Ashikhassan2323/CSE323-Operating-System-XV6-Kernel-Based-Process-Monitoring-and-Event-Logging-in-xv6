#include "types.h"
#include "stat.h"
#include "user.h"

// modified: user command displaying system status, process metrics, descendant trees, and descendant relationship checks.
static char *states[] = {
  [UNUSED]   = "unused",
  [EMBRYO]   = "embryo",
  [SLEEPING] = "sleep ",
  [RUNNABLE] = "runble",
  [RUNNING]  = "run   ",
  [ZOMBIE]   = "zombie",
};

static char *
state_name(int state)
{
  if(state >= 0 && state < (int)(sizeof(states) / sizeof(states[0])) && states[state])
    return states[state];
  return "???   ";
}

// Count active direct children of parent_pid in process snapshot list
static int
count_children(struct procsnap *snaps, int count, int parent_pid)
{
  int n = 0;
  int i;
  for(i = 0; i < count; i++){
    if(snaps[i].ppid == parent_pid && snaps[i].pid != parent_pid){
      n++;
    }
  }
  return n;
}

// Recursively print descendant process tree with formatted branches
static void
print_tree_recursive(struct procsnap *snaps, int count, int cur_pid, int depth, uint is_last_mask)
{
  int total_children = count_children(snaps, count, cur_pid);
  int child_idx = 0;
  int i, d;

  for(i = 0; i < count; i++){
    if(snaps[i].ppid == cur_pid && snaps[i].pid != cur_pid){
      int is_last = (child_idx == total_children - 1);

      printf(1, "    ");
      for(d = 0; d < depth; d++){
        if(is_last_mask & (1 << d))
          printf(1, "    ");
        else
          printf(1, "|   ");
      }

      if(is_last)
        printf(1, "`-- ");
      else
        printf(1, "|-- ");

      printf(1, "%s (PID %d)\n", snaps[i].name, snaps[i].pid);

      uint new_mask = is_last_mask;
      if(is_last)
        new_mask |= (1 << depth);
      else
        new_mask &= ~(1 << depth);

      print_tree_recursive(snaps, count, snaps[i].pid, depth + 1, new_mask);
      child_idx++;
    }
  }
}

// Print root node and full descendant hierarchy
static void
print_descendant_tree(int root_pid, const char *root_name)
{
  struct procsnap snaps[PROCSNAP_MAX];
  int count = ps(snaps, PROCSNAP_MAX);
  int total_children;

  if(count < 0){
    printf(1, "    (unable to fetch process tree)\n");
    return;
  }

  printf(1, "    %s (PID %d)\n", root_name, root_pid);
  total_children = count_children(snaps, count, root_pid);
  if(total_children == 0){
    printf(1, "      (no descendants)\n");
    return;
  }

  print_tree_recursive(snaps, count, root_pid, 0, 0);
}

// modified: display detailed process information and descendant tree for a specific pid.
static void
print_single_proc(int pid)
{
  struct procinfo info;

  if(getprocinfo(pid, &info) < 0){
    printf(1, "ps: pid %d not found\n", pid);
    return;
  }

  printf(1, "Process Information (PID %d):\n", info.pid);
  printf(1, "  Name:             %s\n", info.name);
  printf(1, "  PPID:             %d\n", info.ppid);
  printf(1, "  State:            %s\n", state_name(info.state));
  printf(1, "  Size:             %d bytes\n", info.sz);
  printf(1, "  Creation Tick:    %d\n", info.ctime);
  printf(1, "  CPU Ticks:        %d\n", info.total_ticks);
  printf(1, "  Descendant Ticks: %d\n", info.descendant_ticks);
  printf(1, "  Total CPU Ticks:  %d\n", info.total_cpu_ticks);
  printf(1, "  Last CPU Tick:    %d\n", info.last_cpu_tick);
  printf(1, "  Descendant Tree:\n");
  print_descendant_tree(info.pid, info.name);
}

// modified: check if pid2 is a descendant of pid1 and display the result and ancestry path.
static void
check_descendant_relationship(int pid1, int pid2)
{
  struct procinfo p1, p2;
  struct procsnap snaps[PROCSNAP_MAX];
  int count;
  int curr;
  int path[PROCSNAP_MAX];
  int path_len = 0;
  int found = 0;
  int i, p;

  if(getprocinfo(pid1, &p1) < 0){
    printf(1, "ps: pid %d not found\n", pid1);
    return;
  }
  if(getprocinfo(pid2, &p2) < 0){
    printf(1, "ps: pid %d not found\n", pid2);
    return;
  }

  if(pid1 == pid2){
    printf(1, "PID %d (%s) and PID %d (%s) are the same process (not a strict descendant).\n",
           pid1, p1.name, pid2, p2.name);
    return;
  }

  count = ps(snaps, PROCSNAP_MAX);
  if(count < 0){
    printf(1, "ps: snapshot failed\n");
    return;
  }

  // Trace ancestors of pid2 upwards to see if pid1 is encountered
  curr = pid2;
  while(curr > 0 && path_len < PROCSNAP_MAX){
    path[path_len++] = curr;
    if(curr == pid1){
      found = 1;
      break;
    }
    // Find parent of curr in snapshots
    int parent_pid = 0;
    for(i = 0; i < count; i++){
      if(snaps[i].pid == curr){
        parent_pid = snaps[i].ppid;
        break;
      }
    }
    if(parent_pid == 0 || parent_pid == curr)
      break;
    curr = parent_pid;
  }

  if(found){
    printf(1, "YES: PID %d (%s) IS a descendant of PID %d (%s).\n",
           pid2, p2.name, pid1, p1.name);
    printf(1, "Ancestry path: ");
    for(p = path_len - 1; p >= 0; p--){
      char *node_name = "unknown";
      for(i = 0; i < count; i++){
        if(snaps[i].pid == path[p]){
          node_name = snaps[i].name;
          break;
        }
      }
      printf(1, "%s (PID %d)%s", node_name, path[p], (p > 0) ? " -> " : "\n");
    }
  } else {
    printf(1, "NO: PID %d (%s) is NOT a descendant of PID %d (%s).\n",
           pid2, p2.name, pid1, p1.name);
  }
}

int
main(int argc, char *argv[])
{
  struct sysinfo sinfo;
  struct procsnap snaps[PROCSNAP_MAX];
  struct procinfo pinfo;
  int count;
  int i;

  // modified: support single PID argument for detailed process inspection with descendant tree.
  if(argc == 2){
    print_single_proc(atoi(argv[1]));
    exit();
  }

  // modified: support two PID arguments to check descendant relationship between pid1 and pid2.
  if(argc == 3){
    check_descendant_relationship(atoi(argv[1]), atoi(argv[2]));
    exit();
  }

  if(argc > 3){
    printf(1, "usage: ps [pid] | ps <pid1> <pid2>\n");
    exit();
  }

  // modified: print system summary statistics using getsysinfo.
  if(getsysinfo(&sinfo) == 0){
    printf(1, "=== System Summary ===\n");
    printf(1, "Uptime: %d ticks | Active: %d | Runnable: %d | Sleeping: %d\n",
           sinfo.uptime, sinfo.num_active_proc, sinfo.num_runnable_proc, sinfo.num_sleeping_proc);
    printf(1, "======================\n");
  }

  count = ps(snaps, PROCSNAP_MAX);
  if(count < 0){
    printf(1, "ps: snapshot failed\n");
    exit();
  }

  // modified: format table with metrics collected via getprocinfo.
  printf(1, "PID   PPID  STATE   SIZE    CTIME  CPUTIME DESCTIME TOTTIME LASTCPU NAME\n");
  for(i = 0; i < count; i++){
    if(getprocinfo(snaps[i].pid, &pinfo) == 0){
      printf(1, "%d     %d     %s  %d   %d      %d       %d        %d       %d       %s\n",
             pinfo.pid, pinfo.ppid, state_name(pinfo.state), pinfo.sz,
             pinfo.ctime, pinfo.total_ticks, pinfo.descendant_ticks,
             pinfo.total_cpu_ticks, pinfo.last_cpu_tick, pinfo.name);
    } else {
      printf(1, "%d     %d     %s  -       -      -       -        -        -       %s\n",
             snaps[i].pid, snaps[i].ppid, state_name(snaps[i].state), snaps[i].name);
    }
  }

  exit();
}

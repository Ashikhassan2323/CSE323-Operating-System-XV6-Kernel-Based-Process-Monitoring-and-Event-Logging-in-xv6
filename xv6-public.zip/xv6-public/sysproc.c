#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

// modified: expose feature-2 process history and snapshot syscalls.
extern int proc_history(int, struct proceventrec*, int);
extern int proc_snapshot(struct procsnap*, int);
// modified: expose feature-1 process info and system info syscalls.
extern int proc_getprocinfo(int, struct procinfo*);
extern int proc_getsysinfo(struct sysinfo*);

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_history(void)
{
  int pid;
  struct proceventrec *buf;
  int max;
  struct proceventrec records[HISTORY_MAX];
  int n;

  if(argint(0, &pid) < 0)
    return -1;
  if(argptr(1, (char**)&buf, sizeof(*buf)) < 0)
    return -1;
  if(argint(2, &max) < 0)
    return -1;
  if(max < 0)
    return -1;
  if(max > HISTORY_MAX)
    max = HISTORY_MAX;

  n = proc_history(pid, records, max);
  if(n < 0)
    return -1;
  if(copyout(myproc()->pgdir, (uint)buf, records, n * sizeof(*records)) < 0)
    return -1;
  return n;
}

int
sys_ps(void)
{
  struct procsnap *buf;
  int max;
  struct procsnap snaps[PROCSNAP_MAX];
  int n;

  if(argptr(0, (char**)&buf, sizeof(*buf)) < 0)
    return -1;
  if(argint(1, &max) < 0)
    return -1;
  if(max < 0)
    return -1;
  if(max > PROCSNAP_MAX)
    max = PROCSNAP_MAX;

  n = proc_snapshot(snaps, max);
  if(n < 0)
    return -1;
  if(copyout(myproc()->pgdir, (uint)buf, snaps, n * sizeof(*snaps)) < 0)
    return -1;
  return n;
}

// modified: feature 1 sys_getprocinfo implementation.
int
sys_getprocinfo(void)
{
  int pid;
  struct procinfo *pinfo;
  struct procinfo kinfo;

  if(argint(0, &pid) < 0)
    return -1;
  if(argptr(1, (char**)&pinfo, sizeof(*pinfo)) < 0)
    return -1;

  if(proc_getprocinfo(pid, &kinfo) < 0)
    return -1;

  if(copyout(myproc()->pgdir, (uint)pinfo, &kinfo, sizeof(kinfo)) < 0)
    return -1;

  return 0;
}

// modified: feature 1 sys_getsysinfo implementation.
int
sys_getsysinfo(void)
{
  struct sysinfo *sinfo;
  struct sysinfo ksinfo;

  if(argptr(0, (char**)&sinfo, sizeof(*sinfo)) < 0)
    return -1;

  if(proc_getsysinfo(&ksinfo) < 0)
    return -1;

  if(copyout(myproc()->pgdir, (uint)sinfo, &ksinfo, sizeof(ksinfo)) < 0)
    return -1;

  return 0;
}

#include "types.h"
#include "stat.h"
#include "user.h"

// modified: comprehensive test and visualization program for Feature 1 & Feature 2.
// Creates a multi-level process tree, generates CPU and memory workloads,
// demonstrates live system/process snapshots, deep process inspection with descendant tree,
// descendant relationship checks (ps <pid1> <pid2>), event history tracking, and post-reap descendant accumulation.

static char *state_names[] = {
  [UNUSED]   = "unused",
  [EMBRYO]   = "embryo",
  [SLEEPING] = "sleep ",
  [RUNNABLE] = "runble",
  [RUNNING]  = "run   ",
  [ZOMBIE]   = "zombie",
};

static char *event_names[] = {
  [PROCEVENT_CREATE] = "CREATE",
  [PROCEVENT_FORK]   = "FORK  ",
  [PROCEVENT_EXEC]   = "EXEC  ",
  [PROCEVENT_SLEEP]  = "SLEEP ",
  [PROCEVENT_WAKEUP] = "WAKEUP",
  [PROCEVENT_EXIT]   = "EXIT  ",
  [PROCEVENT_KILL]   = "KILL  ",
};

static char*
get_state_name(int s)
{
  if(s >= 0 && s < (int)(sizeof(state_names)/sizeof(state_names[0])) && state_names[s])
    return state_names[s];
  return "???   ";
}

static char*
get_event_name(int e)
{
  if(e >= 1 && e <= 7 && event_names[e])
    return event_names[e];
  return "UNKNOWN";
}

// Compute-bound workload to consume CPU ticks
static void
busy_work(int loops)
{
  volatile int i, j;
  volatile int x = 0;
  for(i = 0; i < loops; i++){
    for(j = 0; j < 250000; j++){
      x += (i * 7 + j);
    }
  }
}

// Count active direct children of parent_pid in process snapshot list
static int
count_children(struct procsnap *snaps, int count, int parent_pid)
{
  int n = 0;
  int i;
  for(i = 0; i < count; i++){
    if(snaps[i].ppid == parent_pid && snaps[i].pid != parent_pid){
      n++;
    }
  }
  return n;
}

// Recursively print descendant process tree with formatted branches
static void
print_tree_recursive(struct procsnap *snaps, int count, int cur_pid, int depth, uint is_last_mask)
{
  int total_children = count_children(snaps, count, cur_pid);
  int child_idx = 0;
  int i, d;

  for(i = 0; i < count; i++){
    if(snaps[i].ppid == cur_pid && snaps[i].pid != cur_pid){
      int is_last = (child_idx == total_children - 1);

      printf(1, "      ");
      for(d = 0; d < depth; d++){
        if(is_last_mask & (1 << d))
          printf(1, "    ");
        else
          printf(1, "|   ");
      }

      if(is_last)
        printf(1, "`-- ");
      else
        printf(1, "|-- ");

      printf(1, "%s (PID %d)\n", snaps[i].name, snaps[i].pid);

      uint new_mask = is_last_mask;
      if(is_last)
        new_mask |= (1 << depth);
      else
        new_mask &= ~(1 << depth);

      print_tree_recursive(snaps, count, snaps[i].pid, depth + 1, new_mask);
      child_idx++;
    }
  }
}

// Print root node and full descendant hierarchy
static void
print_descendant_tree(int root_pid, const char *root_name)
{
  struct procsnap snaps[PROCSNAP_MAX];
  int count = ps(snaps, PROCSNAP_MAX);
  int total_children;

  if(count < 0){
    printf(1, "      (unable to fetch process tree)\n");
    return;
  }

  printf(1, "      %s (PID %d)\n", root_name, root_pid);
  total_children = count_children(snaps, count, root_pid);
  if(total_children == 0){
    printf(1, "        (no descendants)\n");
    return;
  }

  print_tree_recursive(snaps, count, root_pid, 0, 0);
}

// Check descendant relationship between pid1 and pid2
static int
is_descendant_of(int pid1, int pid2, struct procsnap *snaps, int count)
{
  int curr = pid2;
  int path_len = 0;
  int i;

  if(pid1 == pid2)
    return 0;

  while(curr > 0 && path_len < PROCSNAP_MAX){
    path_len++;
    if(curr == pid1)
      return 1;
    int parent_pid = 0;
    for(i = 0; i < count; i++){
      if(snaps[i].pid == curr){
        parent_pid = snaps[i].ppid;
        break;
      }
    }
    if(parent_pid == 0 || parent_pid == curr)
      break;
    curr = parent_pid;
  }
  return 0;
}

static void
verify_descendant_relation(int pid1, const char *name1, int pid2, const char *name2, int expected)
{
  struct procsnap snaps[PROCSNAP_MAX];
  int count = ps(snaps, PROCSNAP_MAX);
  int actual;

  if(count < 0){
    printf(1, "  [FAIL] Snapshot failed for relationship check\n");
    return;
  }

  actual = is_descendant_of(pid1, pid2, snaps, count);
  if(actual == expected){
    printf(1, "  [PASS] PID %d (%s) -> PID %d (%s): %s (Expected: %s)\n",
           pid1, name1, pid2, name2,
           actual ? "IS DESCENDANT" : "NOT DESCENDANT",
           expected ? "IS DESCENDANT" : "NOT DESCENDANT");
  } else {
    printf(1, "  [FAIL] PID %d (%s) -> PID %d (%s): Got %s, Expected %s\n",
           pid1, name1, pid2, name2,
           actual ? "IS DESCENDANT" : "NOT DESCENDANT",
           expected ? "IS DESCENDANT" : "NOT DESCENDANT");
  }
}

// Display system summary
static void
display_system_summary(void)
{
  struct sysinfo sinfo;
  if(getsysinfo(&sinfo) == 0){
    printf(1, "\n=== [SYSTEM SUMMARY (getsysinfo)] ===\n");
    printf(1, "Uptime: %d ticks | Active Processes: %d | Runnable: %d | Sleeping: %d\n",
           sinfo.uptime, sinfo.num_active_proc, sinfo.num_runnable_proc, sinfo.num_sleeping_proc);
    printf(1, "=====================================\n");
  }
}

// Display full process snapshot table
static void
display_process_table(void)
{
  struct procsnap snaps[PROCSNAP_MAX];
  struct procinfo pinfo;
  int count, i;

  count = ps(snaps, PROCSNAP_MAX);
  if(count < 0){
    printf(1, "ps snapshot failed\n");
    return;
  }

  printf(1, "\n--- [LIVE PROCESS TABLE (ps & getprocinfo)] ---\n");
  printf(1, "PID   PPID  STATE   SIZE    CTIME  CPUTIME DESCTIME TOTTIME LASTCPU NAME\n");
  for(i = 0; i < count; i++){
    if(getprocinfo(snaps[i].pid, &pinfo) == 0){
      printf(1, "%d     %d     %s  %d   %d      %d       %d        %d       %d       %s\n",
             pinfo.pid, pinfo.ppid, get_state_name(pinfo.state), pinfo.sz,
             pinfo.ctime, pinfo.total_ticks, pinfo.descendant_ticks,
             pinfo.total_cpu_ticks, pinfo.last_cpu_tick, pinfo.name);
    } else {
      printf(1, "%d     %d     %s  -       -      -       -        -        -       %s\n",
             snaps[i].pid, snaps[i].ppid, get_state_name(snaps[i].state), snaps[i].name);
    }
  }
  printf(1, "------------------------------------------------\n");
}

// Display single process detailed metrics including descendant tree
static void
display_proc_details(int pid, const char *role)
{
  struct procinfo info;
  if(getprocinfo(pid, &info) < 0){
    printf(1, "Process PID %d not found.\n", pid);
    return;
  }

  printf(1, "\n  [Process Details for PID %d (%s)]\n", pid, role);
  printf(1, "    Name:             %s\n", info.name);
  printf(1, "    PPID:             %d\n", info.ppid);
  printf(1, "    State:            %s\n", get_state_name(info.state));
  printf(1, "    Memory Size:      %d bytes (%d KB)\n", info.sz, info.sz / 1024);
  printf(1, "    Creation Tick:    %d\n", info.ctime);
  printf(1, "    CPU Ticks (Own):  %d\n", info.total_ticks);
  printf(1, "    Descendant Ticks: %d\n", info.descendant_ticks);
  printf(1, "    Total CPU Ticks:  %d (Own + Descendants)\n", info.total_cpu_ticks);
  printf(1, "    Last Active Tick: %d\n", info.last_cpu_tick);
  printf(1, "    Descendant Tree:\n");
  print_descendant_tree(info.pid, info.name);
}

// Display lifecycle event history for a process
static void
display_event_history(int pid, const char *role)
{
  struct proceventrec history_buf[HISTORY_MAX];
  int count, i;

  count = history(pid, history_buf, HISTORY_MAX);
  if(count < 0){
    printf(1, "History retrieval failed for PID %d\n", pid);
    return;
  }

  printf(1, "\n=== [EVENT HISTORY LOG for PID %d (%s)] ===\n", pid, role);
  printf(1, "SEQ       EVENT TYPE   INFO / EXTRA DATA\n");
  for(i = 0; i < count; i++){
    printf(1, "%d\t  %s       %p\n",
           history_buf[i].seq,
           get_event_name(history_buf[i].type),
           history_buf[i].info);
  }
  printf(1, "============================================\n");
}

int
main(int argc, char *argv[])
{
  int sync_pipe[2];
  int root_pid, c1_pid, c2_pid, c3_pid;
  int g1a_pid, g1b_pid, g2a_pid;
  char dummy;

  root_pid = getpid();
  printf(1, "\n=======================================================\n");
  printf(1, "   XV6 PROCESS MONITORING & EVENT LOGGING TEST SUITE   \n");
  printf(1, "=======================================================\n");
  printf(1, "[*] Root Coordinator started with PID %d\n", root_pid);

  // Synchronization pipe to keep all descendants alive until inspected
  if(pipe(sync_pipe) < 0){
    printf(1, "pipe creation failed\n");
    exit();
  }

  printf(1, "[*] Spawning multi-level Process Tree...\n");

  // -----------------------------------------------------------------
  // CHILD 1 (CPU Intensive Subtree: forks 2 grandchildren)
  // -----------------------------------------------------------------
  c1_pid = fork();
  if(c1_pid < 0){
    printf(1, "fork c1 failed\n");
    exit();
  }
  if(c1_pid == 0){
    // Grandchild 1A (Heavy CPU computing)
    g1a_pid = fork();
    if(g1a_pid == 0){
      close(sync_pipe[1]);
      busy_work(25);                 // Consume CPU ticks
      sleep(2);                      // Trigger SLEEP & WAKEUP events
      read(sync_pipe[0], &dummy, 1); // Wait for coordinator release signal
      close(sync_pipe[0]);
      exit();
    }

    // Grandchild 1B (Moderate CPU computing)
    g1b_pid = fork();
    if(g1b_pid == 0){
      close(sync_pipe[1]);
      busy_work(15);                 // Consume CPU ticks
      sleep(2);                      // Trigger SLEEP & WAKEUP events
      read(sync_pipe[0], &dummy, 1); // Wait for coordinator release signal
      close(sync_pipe[0]);
      exit();
    }

    // Child 1 itself does CPU work then waits on pipe
    close(sync_pipe[1]);
    busy_work(10);
    read(sync_pipe[0], &dummy, 1);
    close(sync_pipe[0]);
    wait(); // Reap g1a
    wait(); // Reap g1b
    exit();
  }

  // -----------------------------------------------------------------
  // CHILD 2 (Memory Growth Subtree: allocates heap memory)
  // -----------------------------------------------------------------
  c2_pid = fork();
  if(c2_pid < 0){
    printf(1, "fork c2 failed\n");
    exit();
  }
  if(c2_pid == 0){
    // Child 2 expands its memory address space via sbrk
    sbrk(16384); // Grow memory by 16 KB (4 pages)
    busy_work(8);

    // Grandchild 2A (Allocates additional memory)
    g2a_pid = fork();
    if(g2a_pid == 0){
      close(sync_pipe[1]);
      sbrk(8192); // Grow memory by another 8 KB
      busy_work(10);
      read(sync_pipe[0], &dummy, 1);
      close(sync_pipe[0]);
      exit();
    }

    close(sync_pipe[1]);
    read(sync_pipe[0], &dummy, 1);
    close(sync_pipe[0]);
    wait(); // Reap g2a
    exit();
  }

  // -----------------------------------------------------------------
  // CHILD 3 (State Transition Subtree: sleeps and transitions)
  // -----------------------------------------------------------------
  c3_pid = fork();
  if(c3_pid < 0){
    printf(1, "fork c3 failed\n");
    exit();
  }
  if(c3_pid == 0){
    close(sync_pipe[1]);
    sleep(1);      // Generates SLEEP & WAKEUP event
    busy_work(6);
    sleep(2);      // Generates SLEEP & WAKEUP event
    read(sync_pipe[0], &dummy, 1);
    close(sync_pipe[0]);
    exit();
  }

  // -----------------------------------------------------------------
  // ROOT COORDINATOR: Structure Summary & Observation Phase
  // -----------------------------------------------------------------
  printf(1, "[*] Process tree structure created:\n");
  printf(1, "    Root Coordinator (PID %d)\n", root_pid);
  printf(1, "     |-- Child 1: CPU-Intensive (PID %d)\n", c1_pid);
  printf(1, "     |    |-- Grandchild 1A (Heavy CPU)\n");
  printf(1, "     |    `-- Grandchild 1B (Moderate CPU)\n");
  printf(1, "     |-- Child 2: Memory-Heavy (PID %d, +16KB Heap)\n", c2_pid);
  printf(1, "     |    `-- Grandchild 2A (+8KB Heap)\n");
  printf(1, "     `-- Child 3: Sleep/State-Switching (PID %d)\n", c3_pid);

  // Allow children and grandchildren to execute their compute/memory phases
  printf(1, "\n[*] Allowing tree processes to run and transition across states...\n");
  sleep(15);

  // -----------------------------------------------------------------
  // PHASE 1: System-wide snapshot and Process Table
  // -----------------------------------------------------------------
  display_system_summary();
  display_process_table();

  // -----------------------------------------------------------------
  // PHASE 2: Deep inspection of specific nodes across the tree (with descendant tree)
  // -----------------------------------------------------------------
  printf(1, "\n=== [DEEP METRIC & DESCENDANT TREE INSPECTION] ===");
  display_proc_details(root_pid, "Root Coordinator - Aggregates All Tree Descendants");
  display_proc_details(c1_pid,   "Child 1 - Aggregates Grandchildren 1A and 1B");
  display_proc_details(c2_pid,   "Child 2 - Shows Memory Allocation & Grandchild 2A");
  display_proc_details(c3_pid,   "Child 3 - State Transition Process");

  // -----------------------------------------------------------------
  // PHASE 3: Descendant Relationship Verification (ps <pid1> <pid2>)
  // -----------------------------------------------------------------
  printf(1, "\n=== [DESCENDANT RELATIONSHIP VERIFICATION (ps <pid1> <pid2>)] ===\n");
  verify_descendant_relation(root_pid, "Root", c1_pid, "Child 1", 1);
  verify_descendant_relation(root_pid, "Root", c2_pid, "Child 2", 1);
  verify_descendant_relation(root_pid, "Root", c3_pid, "Child 3", 1);
  verify_descendant_relation(c1_pid, "Child 1", c2_pid, "Child 2", 0);
  verify_descendant_relation(c3_pid, "Child 3", c1_pid, "Child 1", 0);
  verify_descendant_relation(c1_pid, "Child 1", root_pid, "Root", 0);

  // -----------------------------------------------------------------
  // PHASE 4: Lifecycle Event History Logs for processes
  // -----------------------------------------------------------------
  display_event_history(c1_pid,   "Child 1 (Shows CREATE, FORK events for grandchildren, SLEEP)");
  display_event_history(c3_pid,   "Child 3 (Shows CREATE, SLEEP, WAKEUP state transitions)");

  // -----------------------------------------------------------------
  // PHASE 5: Release all processes, verify exit & post-reap accumulation
  // -----------------------------------------------------------------
  printf(1, "\n[*] Releasing all child processes from synchronization lock...\n");
  write(sync_pipe[1], "111111", 6);
  close(sync_pipe[1]);
  close(sync_pipe[0]);

  // Wait for all 3 direct children to exit
  wait();
  wait();
  wait();

  printf(1, "[*] All child and grandchild processes successfully terminated and reaped.\n");

  // Verify post-reap descendant accumulation and empty descendant tree on Root Coordinator
  printf(1, "\n=== [POST-REAP METRIC VERIFICATION ON ROOT COORDINATOR] ===");
  display_proc_details(root_pid, "Root Coordinator After Reaping All Subtrees");

  printf(1, "\n[SUCCESS] Feature 1 (CPU/Memory/Descendant Accounting & Tree), Feature 2 (Event History), and Relationship Checks Verified!\n\n");
  exit();
}

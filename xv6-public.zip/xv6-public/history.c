#include "types.h"
#include "stat.h"
#include "user.h"

// modified: user command that prints the recorded lifecycle history for a pid.
static char *event_name(int type)
{
  switch(type){
  case PROCEVENT_CREATE:
    return "create";
  case PROCEVENT_FORK:
    return "fork";
  case PROCEVENT_EXEC:
    return "exec";
  case PROCEVENT_SLEEP:
    return "sleep";
  case PROCEVENT_WAKEUP:
    return "wakeup";
  case PROCEVENT_EXIT:
    return "exit";
  case PROCEVENT_KILL:
    return "kill";
  default:
    return "unknown";
  }
}

int
main(int argc, char *argv[])
{
  struct proceventrec records[HISTORY_MAX];
  int count;
  int pid;
  int i;

  if(argc != 2){
    printf(1, "usage: history pid\n");
    exit();
  }

  pid = atoi(argv[1]);
  count = history(pid, records, HISTORY_MAX);
  if(count < 0){
    printf(1, "history: pid %d not found\n", pid);
    exit();
  }

  printf(1, "History for pid %d\n", pid);
  printf(1, "SEQ  EVENT    INFO\n");
  for(i = 0; i < count; i++)
    printf(1, "%d %s %p\n",
           records[i].seq, event_name(records[i].type), records[i].info);

  exit();
}

# **[CSE 323] Project Submission Guidelines** 

Final submission of the CSE323 project is due on **August 28, 2026 (Friday 11:59 PM)** . This will be a strict deadline, as we plan to release all evaluation scores before you take the final exam. Therefore, **any late submission will be highly penalized (20% reduction per day after the deadline)** . You are advised to prepare your report early and submit it within the specified deadline. Your submission will contain two items: 

1. **Project Report** ( `GroupXX_report.pdf` ): This is the main document describing your project goals, implementation, validation, and conclusions. 

2. **Diff Report** ( `diff_report.txt` ): This file summarizes the differences between the original and modified codebases as required. 

## **Instructions for Project Report** 

You may use up to 6 pages for the report. Follow the structure outlined below, and make sure each section includes enough detail to address the key questions (see examples). You may add subsections within each section to organize your writing more clearly. 

### 1. **Project Goals** 

- What features are you implementing? 

- What are the default implementation strategies in xv6 for these features? 

- How do your added features improve the xv6 kernel? 

### 2. **Modifications** 

- What challenges arise when implementing the new features? 

- What system calls are needed, and what purpose does each one serve? 

- What modifications did you make to the kernel, and how do they connect to support the new features? 

### 3. **Evaluation** 

- How do you evaluate whether the modified xv6 kernel successfully provides the proposed features? 

- What user program(s) did you write to test the new features? 

- What outcomes from these user programs demonstrate the new kernel capabilities? Consider including tables and plots to compare the default _vs._ your version. 

### 4. **Conclusions** 

- What couldn’t be completed within the semester, and why? 

- How could your implementation be improved further to approach modern OS behavior? 

- How did each group member contribute to the project? 

1 

## **Instructions for Diff Report** 

Each group is required to submit a diff report showing the differences between two versions of the xv6 codebase (the original codebase _vs._ your updated version). Only `.c` and `.h` files should be included in the diff report. Follow the instructions below: 

### **Step 1: Prepare a Git Repository** 

- (a) Copy the original and your updated xv6 folders ( `xv6-original` and `xv6-modified` ) into a common directory (e.g., `~/Desktop` ). Using your Linux/MacOS terminal, create a new temporary folder ( `compare_repo` ) in the same directory and initialize it as a git repository. 

```
$mkdircompare_repo
$ls
>compare_repoxv6-modifiedxv6-original
$cdcompare_repo
$gitinit
```

- (b) Copy the original version of the code into `compare_repo` and commit: 

```
$cp-r../xv6-original/*.
$gitadd.
$gitcommit-m"original"
```

- (c) Copy the modified version of the code into `compare_repo` to overwrite the original codes and commit: 

```
$cp-r../xv6-modified/*.
$gitadd.
$gitcommit-m"modified"
```

### **Step 2: Generate the Diff Report** 

- (a) To generate a diff showing only `.c` and `.h` file changes: 

```
$gitdiffHEAD~1HEAD'*.c''*.h'>../diff_report.txt
$cd..
$ls
>compare_repodiff_report.txtxv6-modifiedxv6-original
```

- (b) This will create a file named `diff_report.txt` in the parent directory, containing all differences in `.c` and `.h` files between the two versions. 

### **Step 3: Submit the Diff Report** 

- (a) Ensure the file `diff_report.txt` contains only relevant diffs. 

- (b) Submit the `diff_report.txt` along with your project report (PDF) on Canvas. 

- (c) One member from each group will have to submit. 

2 


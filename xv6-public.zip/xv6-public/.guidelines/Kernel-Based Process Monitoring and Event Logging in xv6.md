# Kernel-Based Process Monitoring and Event Logging in xv6

## Project Proposal

### Group Context
This project will be completed by a group of three students as a self-driven xv6 extension project.

### Introduction
This project proposes the design and implementation of a lightweight process monitoring and event logging framework in xv6. The proposed system will extend the kernel with a small set of practical features that allow users to obtain process information, view basic system status, inspect a history of significant process events, view process descendant trees, and query descendant relationships. The goal is to improve observability and educational value without altering the fundamental structure of xv6.

### Objectives
The main objectives of this project are to:
- Extend xv6 with additional process-related system calls.
- Provide users with basic process-level information such as PID, state, name, and runtime.
- Offer a simple mechanism to inspect the current system status.
- Record and display a compact history of important lifecycle events for each process.
- Inspect process hierarchy through structured descendant trees and descendant relationship queries.
- Demonstrate the practical application of kernel programming, system calls, and process management concepts.

### Proposed Features
The project will focus on two merged and practical features that are feasible within the scope of xv6.

#### Feature 1: Process Information and System Summary
A new system call, `getprocinfo(int pid, struct procinfo *info)`, will be implemented to return detailed information about a specific process. The information will include:
- Process ID (PID)
- Parent Process ID (PPID)
- Process name
- Current process state
- Process size
- Creation time in ticks
- Total execution time in ticks
- Last CPU tick or wait time
- CPU time consumed by the process itself and its descendants

In addition, a second system call, `getsysinfo(struct sysinfo *info)`, will provide basic system-wide statistics such as:
- Number of active processes
- Number of runnable processes
- Number of sleeping processes
- System uptime

These two system calls together will form a simple monitoring interface for the kernel.

To support the descendant CPU-time requirement, the kernel will accumulate execution time across a process tree created through `fork()`. This will allow the report to show both the time used by the process itself and the time consumed by child and descendant processes.

#### Feature 2: Process Event Logging, Hierarchy Inspection, and Process Listing
A lightweight event logging mechanism will be added to record significant process events during execution. The kernel will store a small history of events such as:
- Process created
- Process executed
- Process slept
- Process woke up
- Process exited
- Process killed

A user-level utility, `ps`, will provide comprehensive process table listing and hierarchy inspection:
- `ps`: displays a system summary and a table of all active processes using `getsysinfo()` and `getprocinfo()`.
- `ps <pid>`: displays detailed process attributes along with a visual **Descendant Tree** field showing process names and PIDs in a hierarchical branch format.
- `ps <pid1> <pid2>`: checks and reports whether `pid2` is a descendant of `pid1` or not, displaying process names, PIDs, and the ancestry path.

Additionally, a system call `history(int pid, struct proceventrec *records, int max)` and companion user tool `history <pid>` will allow users to view the lifecycle event history of a selected process.

### User Programs and Validation
The implementation will include user-space programs that demonstrate the impact of both features.

- `ps`: displays process information collected through `getprocinfo()` and `getsysinfo()`, renders visual descendant trees for single PID inspection (`ps <pid>`), and checks descendant relationships between two PIDs (`ps <pid1> <pid2>`).
- `history`: displays the event log for a selected process using `history(pid)`.
- `featuretest`: a comprehensive test suite that constructs a multi-tiered process tree, executes compute/memory/sleep workloads, displays snapshots, deep inspects nodes (including their descendant trees), verifies descendant relationships (`ps <pid1> <pid2>` logic), validates lifecycle event logs, and confirms post-reap CPU time accumulation.
- `forktest` and `usertests`: used to validate stability, descendant CPU-time accumulation, event logging, and state transitions under stress.

These user programs will be used in the final report to show the practical impact of the implementation and to verify that the new kernel features behave correctly.

### Methodology
The implementation will involve modifying the xv6 kernel to store additional process metadata and event records. The relevant kernel components will include `proc.h`, `proc.c`, `sysproc.c`, `syscall.c`, `syscall.h`, and `defs.h`. New system calls will be added and exposed to user programs through the existing xv6 system-call interface. User-level utilities will then be developed to invoke these features and present the information in a readable format.

### Expected Results
Upon successful completion of the project, xv6 will provide improved process monitoring capabilities. Users will be able to:
- Retrieve detailed information about running processes.
- View basic system summary statistics.
- Display a simple list of active processes using `ps`.
- Inspect the descendant tree of a process with names and PIDs using `ps <pid>`.
- Check if a process is a descendant of another process using `ps <pid1> <pid2>`.
- Inspect the lifecycle event history of a selected process using `history(pid)`.
- Gain better insight into process behavior and kernel-level execution.
- Observe the CPU time spent by a process and its descendants.
- Verify the implementation through user-level test programs.

### Conclusion
This project is both practical and educational for an xv6-based operating systems course. It introduces students to important concepts such as process management, kernel data structures, system call implementation, and user-kernel communication. Although the proposed features are simpler than full Linux-style monitoring tools, they are realistic, implementable, and sufficient to significantly improve the observability and learning value of xv6.

# Kernel-Based Process Monitoring and Event Logging in xv6

**Course**: CSE 323: Operating Systems  
**Project Report** — Group Submission (`GroupXX_report.pdf` / `GroupXX_report.md`)  

---

## 1. Project Goals

### 1.1 Features Implemented
This project designs and implements a lightweight, comprehensive process monitoring and event logging framework within the xv6 operating system. The implementation introduces two merged and practical feature sets:

1. **Feature 1: Process Information, Descendant Accounting, and System Summary**
   - **Process-Level Inspection (`getprocinfo`)**: A new system call `getprocinfo(int pid, struct procinfo *info)` that returns detailed process metadata, memory size, creation tick timestamp (`ctime`), CPU execution time in clock ticks (`total_ticks`), last scheduled tick (`last_cpu_tick`), descendant execution time (`descendant_ticks`), and combined CPU runtime (`total_cpu_ticks`).
   - **System Summary Statistics (`getsysinfo`)**: A new system call `getsysinfo(struct sysinfo *info)` that provides system-wide operational metrics including active process count, runnable process count, sleeping process count, and total system uptime in timer ticks.
   - **Tree-Wide Descendant CPU Accumulation**: Dynamic and post-reap aggregation of CPU execution time across multi-level `fork()` process trees.
   - **Process Hierarchy Inspection & Relationship Queries (`ps`)**: An enhanced user-level utility supporting:
     - `ps`: Displays system-wide summary and a formatted tabular view of active processes.
     - `ps <pid>`: Displays detailed process metrics accompanied by a structured ASCII **Descendant Tree** showing process names and PIDs.
     - `ps <pid1> <pid2>`: Queries and displays whether `pid2` is a descendant of `pid1` along with the full ancestry chain.

2. **Feature 2: Process Lifecycle Event Logging and History Tracing**
   - **Bounded Event Ring Buffer**: Per-process circular buffers (`HISTORY_MAX = 16`) recording significant lifecycle transitions: `CREATE`, `FORK`, `EXEC`, `SLEEP`, `WAKEUP`, `EXIT`, and `KILL`.
   - **Event History System Call (`history`)**: A new system call `history(int pid, struct proceventrec *dst, int max)` and user command `history <pid>` allowing users to inspect the chronological sequence of lifecycle events for any active process.
   - **Process Table Snapshotting (`ps` syscall)**: A kernel snapshot facility `ps(struct procsnap *dst, int max)` returning atomic process states, PIDs, PPIDs, and process names.

---

### 1.2 Default Implementation Strategies in xv6
In standard MIT xv6, process monitoring and runtime observability are practically non-existent:
- **No Runtime Accounting**: Default xv6 does not record process creation timestamps, execution duration, CPU consumption, or scheduling history. The timer interrupt handler merely triggers `yield()` for round-robin scheduling without accumulating ticks per process.
- **No User-Level Process Inspection**: There are no system calls in default xv6 allowing user applications to inspect process states, parent-child relationships, or memory utilization. The only debugging tool is `procdump()` (triggered by pressing `Ctrl-P` in the console), which dumps raw text to the serial terminal without structured user-space access.
- **No Process Lifecycle Auditing**: When a process sleeps, wakes up, forks, executes a binary, or terminates, no record is retained. Diagnosing synchronization issues or scheduling anomalies requires invasive manual `cprintf()` statements.
- **No Hierarchy Representation**: Default xv6 maintains process parent pointers (`p->parent`) strictly for `wait()` and `exit()` reparenting to `initproc`, with no mechanism to query or visualize descendant trees.

---

### 1.3 Improvements to the xv6 Kernel
Our extensions transform xv6 into an observable, educational operating system while preserving its clean, minimalistic kernel design:
- **Rich User Observability**: System status and fine-grained per-process metrics are accessible to user programs via standardized system calls and command-line utilities.
- **Accurate Resource Accounting**: Both self-consumed and descendant CPU times are tracked accurately, enabling workload characterization across process hierarchies.
- **Process Hierarchy Exploration**: Users can view the exact structural descendant tree of any process and test ancestral relationships between arbitrary PIDs (`ps <pid1> <pid2>`).
- **Debugging & Auditing Trail**: The monotonic sequence-numbered event log allows students and instructors to trace state transitions, verify synchronization ordering, and diagnose race conditions or deadlocks.

---

## 2. Modifications

### 2.1 Challenges Encountered

1. **Dual-Mode Descendant CPU Accumulation**:
   - *Challenge*: A process may have both active (running/sleeping) descendants and terminated descendants that have already been reaped.
   - *Solution*: When a child terminates and is reaped in `wait()`, its total CPU runtime (own ticks + its own reaped descendant ticks) is accumulated into `curproc->descendant_ticks`. When `getprocinfo()` is called on a live process, the kernel combines `p->descendant_ticks` (from reaped descendants) with a dynamic traversal of `ptable.proc` for all currently active descendants (`is_descendant(target, ancestor)`), avoiding double-counting.

2. **Fine-Grained Concurrency & Locking for Event Logging**:
   - *Challenge*: Process events occur at high frequency in critical paths (`sleep()`, `wakeup1()`, `fork()`, `kill()`). Relying exclusively on the global `ptable.lock` would create severe lock contention.
   - *Solution*: Introduced a dedicated spinlock `historylock` protecting the per-process history ring buffers and a global monotonic sequence counter `historyseq`. This decouples history operations from process table scheduling locks while ensuring globally ordered sequence numbers.

3. **Hierarchical Tree Traversal in User Space**:
   - *Challenge*: Visualizing process hierarchies and determining arbitrary descendant relationships without modifying xv6 kernel memory constraints.
   - *Solution*: Designed the `ps()` snapshot syscall to provide an atomic array of active processes (`pid`, `ppid`, `state`, `name`). User space utilities (`ps.c`, `featuretest.c`) implement recursive branch formatting (`|--`, `` `-- ``, `|   `) and ancestor path tracing cleanly without dynamic heap thrashing.

4. **Safe User-Kernel Boundary Data Transfer**:
   - *Challenge*: Ensuring user memory pointers provided to `getprocinfo`, `getsysinfo`, `history`, and `ps` are safely verified before copying kernel structures.
   - *Solution*: Utilized `argptr()` and `argint()` syscall argument parsers with bounded buffer checks (`HISTORY_MAX`, `PROCSNAP_MAX`), preventing kernel faults or buffer overflows.

---

### 2.2 System Calls Added

| System Call | Prototype | Purpose |
| :--- | :--- | :--- |
| `getprocinfo` | `int getprocinfo(int pid, struct procinfo *info)` | Retrieves detailed process attributes, memory size, timestamps, and own/descendant CPU ticks for a specified PID. |
| `getsysinfo` | `int getsysinfo(struct sysinfo *info)` | Retrieves system summary metrics (counts of active, runnable, sleeping processes, and system uptime in ticks). |
| `ps` | `int ps(struct procsnap *dst, int max)` | Takes a snapshot of all active and terminating processes (PID, PPID, state, process name). |
| `history` | `int history(int pid, struct proceventrec *dst, int max)` | Retrieves the bounded history of lifecycle event records (sequence, event type, extra data) for a specified PID. |

---

### 2.3 Kernel Modifications & Component Connectivity

The implementation touches key kernel and user components as depicted below:

```
+-------------------------------------------------------------------------+
|                              User Space                                 |
|   +-------------------+    +--------------------+   +---------------+   |
|   |  ps / ps <pid>    |    |   history <pid>    |   |  featuretest  |   |
|   |  ps <pid1> <pid2> |    +---------+----------+   +-------+-------+   |
|   +---------+---------+              |                      |           |
+-------------|------------------------|----------------------|-----------+
              | SYS_ps / SYS_getprocinfo / SYS_getsysinfo / SYS_history   
+-------------v------------------------v----------------------v-----------+
|                          Syscall Dispatch Layer                         |
|   syscall.c / syscall.h / sysproc.c / usys.S / user.h / defs.h          |
+--------------------------------------+----------------------------------+
                                       |
+--------------------------------------v----------------------------------+
|                              Kernel Core                                |
|   +-----------------------------------------------------------------+   |
|   | proc.h: struct procinfo, struct sysinfo, struct proceventrec,  |   |
|   |         struct procsnap, struct proc (ctime, ticks, history)    |   |
|   +-----------------------------------------------------------------+   |
|   | trap.c: Timer interrupt handler -> Increments total_ticks        |   |
|   | proc.c: allocproc() -> Initializes ctime, logs PROCEVENT_CREATE |   |
|   |         fork()      -> Logs PROCEVENT_FORK                     |   |
|   |         exec.c      -> Logs PROCEVENT_EXEC                     |   |
|   |         sleep()     -> Logs PROCEVENT_SLEEP                    |   |
|   |         wakeup1()   -> Logs PROCEVENT_WAKEUP                   |   |
|   |         kill()      -> Logs PROCEVENT_KILL                     |   |
|   |         exit()      -> Logs PROCEVENT_EXIT                     |   |
|   |         wait()      -> Reaps zombie child, accumulates ticks   |   |
|   |         scheduler() -> Tracks last_cpu_tick                     |   |
|   |         proc_getprocinfo(), proc_getsysinfo(), proc_snapshot()  |   |
|   +-----------------------------------------------------------------+   |
+-------------------------------------------------------------------------+
```

#### Detailed Component Changes:
1. **Header Definitions ([proc.h](file:///home/kabir/project323/xv6-public/proc.h) & [user.h](file:///home/kabir/project323/xv6-public/user.h))**:
   - Added `struct procinfo`, `struct sysinfo`, `struct proceventrec`, `struct procsnap`, and `enum procevent`.
   - Extended `struct proc` with `ctime`, `total_ticks`, `last_cpu_tick`, `descendant_ticks`, `history[HISTORY_MAX]`, `history_head`, and `history_count`.
2. **CPU Accounting ([trap.c](file:///home/kabir/project323/xv6-public/trap.c))**:
   - In `trap()` under `T_IRQ0 + IRQ_TIMER`, when `myproc() && myproc()->state == RUNNING`, the kernel increments `myproc()->total_ticks++` and updates `myproc()->last_cpu_tick = ticks`.
3. **Process Lifecycle & Tree Accounting ([proc.c](file:///home/kabir/project323/xv6-public/proc.c))**:
   - `allocproc()`: Sets `ctime = ticks`, `last_cpu_tick = ticks`, `total_ticks = 0`, `descendant_ticks = 0`, and records `PROCEVENT_CREATE`.
   - `wait()`: Reaps `ZOMBIE` processes and accumulates runtime: `curproc->descendant_ticks += p->total_ticks + p->descendant_ticks`.
   - `is_descendant()` & `get_descendant_ticks()`: Recursively traverse parent pointers within `ptable` to aggregate active descendant execution time.
   - `proc_getprocinfo()`, `proc_getsysinfo()`, and `proc_snapshot()`: Implement thread-safe kernel retrieval routines.
   - Hooked `proc_logevent()` into `allocproc()`, `fork()`, `exec()` ([exec.c](file:///home/kabir/project323/xv6-public/exec.c)), `sleep()`, `wakeup1()`, `kill()`, and `exit()`.
4. **Syscall Wiring ([syscall.h](file:///home/kabir/project323/xv6-public/syscall.h), [syscall.c](file:///home/kabir/project323/xv6-public/syscall.c), [sysproc.c](file:///home/kabir/project323/xv6-public/sysproc.c), [defs.h](file:///home/kabir/project323/xv6-public/defs.h), [usys.S](file:///home/kabir/project323/xv6-public/usys.S))**:
   - Added `SYS_history (22)`, `SYS_ps (23)`, `SYS_getprocinfo (24)`, `SYS_getsysinfo (25)`.
5. **User Utilities**:
   - [ps.c](file:///home/kabir/project323/xv6-public/ps.c): Formats system summary, snapshot table, single-process metrics with formatted **Descendant Tree**, and **Descendant Relationship Checks** (`ps <pid1> <pid2>`).
   - [history.c](file:///home/kabir/project323/xv6-public/history.c): Displays event logs with sequence numbers and extra info.
   - [featuretest.c](file:///home/kabir/project323/xv6-public/featuretest.c): Automated verification suite covering multi-tiered workloads, live snapshots, deep tree inspections, descendant relationship verification, event history tracing, and post-reap descendant accumulation.

---

## 3. Evaluation

### 3.1 Evaluation Methodology
We evaluated the framework through multiple complementary test workloads:
1. **Interactive CLI Testing (`ps`, `history`)**:
   - Validated standard process table listing (`ps`), single process inspection with ASCII descendant trees (`ps <pid>`), and ancestor-descendant queries (`ps <pid1> <pid2>`).
2. **Comprehensive Automated Test Suite (`featuretest`)**:
   - Spawns a 3-tier process hierarchy: Root Coordinator $\rightarrow$ Child 1 (CPU compute), Child 2 (Memory `sbrk`), Child 3 (Sleep/Wakeup transitions) $\rightarrow$ Grandchildren 1A, 1B, 2A.
   - Holds child processes in synchronized states using a pipe lock while verifying live system metrics, memory allocations, CPU ticks, and descendant trees.
   - Verifies positive and negative descendant relationships (`ps <pid1> <pid2>` logic).
   - Validates lifecycle event sequences in history buffers.
   - Releases children, waits for termination, and verifies post-reap descendant CPU time accumulation.
3. **Stress and Concurrency Testing (`forktest`, `usertests`)**:
   - Ran `forktest` (allocating maximum processes until table exhaustion) and `usertests` (comprehensive filesystem, memory, pipe, and IPC tests) to ensure system stability, lock safety, and zero panics.

---

### 3.2 Feature Comparison

#### Table 1: Feature Comparison: Default xv6 vs. Modified xv6

| Feature / Metric | Default xv6 | Modified xv6 (Our Implementation) |
| :--- | :--- | :--- |
| **System Summary** | None | Real-time counts (Active, Runnable, Sleeping, Uptime) via `getsysinfo()` |
| **Process Inspection** | None (only console `Ctrl-P`) | User-space inspection (`getprocinfo()`, `ps <pid>`) |
| **CPU Time Accounting** | None | Per-process CPU ticks and last scheduled tick timestamp |
| **Descendant CPU Accounting** | None | Real-time dynamic traversal + post-reap accumulation |
| **Descendant Tree Visualization** | None | Formatted ASCII tree showing names and PIDs (`ps <pid>`) |
| **Descendant Relationship Check** | None | Ancestry verification and path display (`ps <pid1> <pid2>`) |
| **Lifecycle Event History** | None | Monotonic ring buffer (`history()`, `history <pid>`) |
| **User Space Utilities** | Minimal standard tools | Enhanced `ps`, `history`, `featuretest` |

---

### 3.3 Experimental Results & Demonstration

#### 1. System Summary & Live Process Table (`ps`)
```text
$ ps
=== System Summary ===
Uptime: 200 ticks | Active: 3 | Runnable: 1 | Sleeping: 2
======================
PID   PPID  STATE   SIZE    CTIME  CPUTIME DESCTIME TOTTIME LASTCPU NAME
1     0     sleep   12288   0      2       3        5       3       init
2     1     sleep   16384   3      0       4        4       414     sh
3     2     run     16384   199    5       0        5       200     ps
```

#### 2. Process Inspection with Descendant Tree (`ps 1`)
```text
$ ps 1
Process Information (PID 1):
  Name:             init
  PPID:             0
  State:            sleep 
  Size:             12288 bytes
  Creation Tick:    0
  CPU Ticks:        2
  Descendant Ticks: 7
  Total CPU Ticks:  9
  Last CPU Tick:    3
  Descendant Tree:
    init (PID 1)
    `-- sh (PID 2)
        `-- ps (PID 4)
```

#### 3. Descendant Relationship Queries (`ps <pid1> <pid2>`)
```text
$ ps 1 2
YES: PID 2 (sh) IS a descendant of PID 1 (init).
Ancestry path: init (PID 1) -> sh (PID 2)

$ ps 2 1
NO: PID 1 (init) is NOT a descendant of PID 2 (sh).

$ ps 99
ps: pid 99 not found
```

#### 4. Automated Multi-Tier Verification (`featuretest`)
```text
$ featuretest

=======================================================
   XV6 PROCESS MONITORING & EVENT LOGGING TEST SUITE   
=======================================================
[*] Root Coordinator started with PID 8
[*] Spawning multi-level Process Tree...
[*] Process tree structure created:
    Root Coordinator (PID 8)
     |-- Child 1: CPU-Intensive (PID 9)
     |    |-- Grandchild 1A (Heavy CPU)
     |    `-- Grandchild 1B (Moderate CPU)
     |-- Child 2: Memory-Heavy (PID 10, +16KB Heap)
     |    `-- Grandchild 2A (+8KB Heap)
     `-- Child 3: Sleep/State-Switching (PID 11)

[*] Allowing tree processes to run and transition across states...

=== [SYSTEM SUMMARY (getsysinfo)] ===
Uptime: 412 ticks | Active Processes: 9 | Runnable: 1 | Sleeping: 8
=====================================

--- [LIVE PROCESS TABLE (ps & getprocinfo)] ---
PID   PPID  STATE   SIZE    CTIME  CPUTIME DESCTIME TOTTIME LASTCPU NAME
1     0     sleep   12288   0      2       92       94      3       init
2     1     sleep   16384   3      0       93       93      414     sh
8     2     run     20480   352    65      23       88      413     featuretest
9     8     sleep   20480   359    2       7        9       371     featuretest
10    8     sleep   36864   359    1       2        3       366     featuretest
11    8     sleep   20480   359    1       0        1       374     featuretest
12    9     sleep   20480   359    4       0        4       370     featuretest
13    9     sleep   20480   359    3       0        3       369     featuretest
14    10    sleep   28672   360    2       0        2       366     featuretest
------------------------------------------------

=== [DEEP METRIC & DESCENDANT TREE INSPECTION] ===
  [Process Details for PID 8 (Root Coordinator - Aggregates All Tree Descendants)]
    Name:             featuretest
    PPID:             2
    State:            run   
    Memory Size:      20480 bytes (20 KB)
    Creation Tick:    352
    CPU Ticks (Own):  65
    Descendant Ticks: 23
    Total CPU Ticks:  88 (Own + Descendants)
    Last Active Tick: 413
    Descendant Tree:
      featuretest (PID 8)
      |-- featuretest (PID 9)
      |   |-- featuretest (PID 12)
      |   `-- featuretest (PID 13)
      |-- featuretest (PID 10)
      |   `-- featuretest (PID 14)
      `-- featuretest (PID 11)

  [Process Details for PID 9 (Child 1 - Aggregates Grandchildren 1A and 1B)]
    Name:             featuretest
    PPID:             8
    State:            sleep 
    Memory Size:      20480 bytes (20 KB)
    Creation Tick:    359
    CPU Ticks (Own):  2
    Descendant Ticks: 7
    Total CPU Ticks:  9 (Own + Descendants)
    Last Active Tick: 371
    Descendant Tree:
      featuretest (PID 9)
      |-- featuretest (PID 12)
      `-- featuretest (PID 13)

=== [DESCENDANT RELATIONSHIP VERIFICATION (ps <pid1> <pid2>)] ===
  [PASS] PID 8 (Root) -> PID 9 (Child 1): IS DESCENDANT (Expected: IS DESCENDANT)
  [PASS] PID 8 (Root) -> PID 10 (Child 2): IS DESCENDANT (Expected: IS DESCENDANT)
  [PASS] PID 8 (Root) -> PID 11 (Child 3): IS DESCENDANT (Expected: IS DESCENDANT)
  [PASS] PID 9 (Child 1) -> PID 10 (Child 2): NOT DESCENDANT (Expected: NOT DESCENDANT)
  [PASS] PID 11 (Child 3) -> PID 9 (Child 1): NOT DESCENDANT (Expected: NOT DESCENDANT)
  [PASS] PID 9 (Child 1) -> PID 8 (Root): NOT DESCENDANT (Expected: NOT DESCENDANT)

=== [EVENT HISTORY LOG for PID 11 (Child 3 (Shows CREATE, SLEEP, WAKEUP))] ===
SEQ       EVENT TYPE   INFO / EXTRA DATA
179       CREATE       0
180       FORK         8
185       SLEEP        801182A0
186       WAKEUP       801182A0
191       SLEEP        801182A0
192       WAKEUP       801182A0
195       SLEEP        8DF2C234
============================================

[*] Releasing all child processes from synchronization lock...
[*] All child and grandchild processes successfully terminated and reaped.

=== [POST-REAP METRIC VERIFICATION ON ROOT COORDINATOR] ===
  [Process Details for PID 8 (Root Coordinator After Reaping All Subtrees)]
    Name:             featuretest
    PPID:             2
    State:            run   
    Memory Size:      20480 bytes (20 KB)
    Creation Tick:    352
    CPU Ticks (Own):  87
    Descendant Ticks: 14
    Total CPU Ticks:  101 (Own + Descendants)
    Last Active Tick: 470
    Descendant Tree:
      featuretest (PID 8)
        (no descendants)

[SUCCESS] Feature 1 (CPU/Memory/Descendant Accounting & Tree), Feature 2 (Event History), and Relationship Checks Verified!
```

---

## 4. Conclusions

### 4.1 Summary of Deliverables
All project goals were fully realized, verified, and integrated into the xv6 kernel:
1. Four new system calls (`getprocinfo`, `getsysinfo`, `history`, `ps`) implemented and exposed to user space.
2. Kernel-level runtime accounting and tree-wide descendant CPU accumulation implemented and validated.
3. Thread-safe, bounded event history logging with monotonic sequence numbers operational across all process state transitions.
4. User tools `ps` (summary, table, single PID inspection, ASCII descendant trees, and descendant relationship checks) and `history` implemented.
5. Verification suite `featuretest` confirming all features, with `forktest` and `usertests` proving regression safety and kernel stability.

---

### 4.2 Limitations and Future Work
- **High-Resolution Timing**: Timer accounting currently operates at 100 Hz timer tick granularity (~10ms). Future enhancements could integrate APIC timer or x86 `rdtsc` instruction counters for sub-millisecond precision.
- **Persistent Audit Logs**: Event logs reside in memory within per-process buffers. Integrating a kernel log daemon to flush historical event streams to the disk filesystem (e.g. `/var/log/xv6_audit.log`) would mirror production Unix logging.
- **Extended Metric Dimensions**: Future work can add user vs. kernel mode time separation (`utime` / `stime`), I/O block counts, and open file descriptor enumeration to `struct procinfo`.

---

### 4.3 Group Contributions

- **Group Member 1**:
  - Designed and implemented Feature 1 process accounting data structures (`procinfo`, `sysinfo`).
  - Implemented CPU tick accounting in `trap.c` and dynamic / post-reap descendant accumulation algorithms in `proc.c`.
  - Implemented `getprocinfo()` and `getsysinfo()` system call dispatching in `sysproc.c`.

- **Group Member 2**:
  - Designed and implemented Feature 2 event history ring buffering and `historylock` concurrency in `proc.c`.
  - Instrumented lifecycle event hooks across `allocproc()`, `fork()`, `exec.c`, `sleep()`, `wakeup1()`, `kill()`, and `exit()`.
  - Implemented `history()` and `ps()` system call handlers.

- **Group Member 3**:
  - Implemented user utilities `ps.c` (system summary, table view, ASCII descendant tree generator, and `ps <pid1> <pid2>` descendant checker) and `history.c`.
  - Authored comprehensive test suite `featuretest.c` and conducted stress testing with `forktest` and `usertests`.
  - Prepared project documentation and `diff_report.txt`.

*(Note: Replace placeholder group member names with actual names and student IDs prior to submission).*

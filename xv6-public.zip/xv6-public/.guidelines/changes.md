# Changes for Kernel-Based Process Monitoring and Event Logging (Feature 1 & Feature 2)

## Summary
This document describes the concrete code changes made to implement both proposed features in xv6:
- **Feature 1: Process Information and System Summary** — Per-process CPU execution time tracking, creation timestamp, last CPU tick, descendant execution time accumulation across process trees (`fork()` and `wait()`), system-wide status query (`getsysinfo`), and single-process query (`getprocinfo`).
- **Feature 2: Process Event Logging & History** — Bounded per-process event history ring buffers (`HISTORY_MAX`), monotonic sequence numbering (`historyseq`), and live process snapshotting exposed to user space via `history(pid)` and `ps`.

---

## Modified and Added Files

### 1. Header Files and Definitions
- [proc.h](../proc.h)
  - Added limits: `HISTORY_MAX 16`, `PROCSNAP_MAX 64`.
  - Added `enum procevent`: `PROCEVENT_CREATE`, `PROCEVENT_FORK`, `PROCEVENT_EXEC`, `PROCEVENT_SLEEP`, `PROCEVENT_WAKEUP`, `PROCEVENT_EXIT`, `PROCEVENT_KILL`.
  - Defined `struct proceventrec` (`seq`, `type`, `info`) and `struct procsnap` (`pid`, `ppid`, `state`, `name`).
  - Defined `struct procinfo` (`pid`, `ppid`, `name`, `state`, `sz`, `ctime`, `total_ticks`, `last_cpu_tick`, `descendant_ticks`, `total_cpu_ticks`) for `getprocinfo`.
  - Defined `struct sysinfo` (`num_active_proc`, `num_runnable_proc`, `num_sleeping_proc`, `uptime`) for `getsysinfo`.
  - Extended `struct proc` with:
    - History ring buffer: `struct proceventrec history[HISTORY_MAX]; int history_head; int history_count;`
    - Feature 1 timing fields: `uint ctime; uint total_ticks; uint last_cpu_tick; uint descendant_ticks;`

- [user.h](../user.h)
  - Declared user-visible definitions for `HISTORY_MAX`, `PROCSNAP_MAX`, `enum procstate`, `enum procevent`, `struct proceventrec`, `struct procsnap`, `struct procinfo`, `struct sysinfo`.
  - Declared system call prototypes:
    - `int history(int, struct proceventrec*, int);`
    - `int ps(struct procsnap*, int);`
    - `int getprocinfo(int, struct procinfo*);`
    - `int getsysinfo(struct sysinfo*);`

- [defs.h](../defs.h)
  - Forward-declared `struct proceventrec`, `struct procsnap`, `struct procinfo`, `struct sysinfo`.
  - Declared kernel helper functions:
    - `int proc_history(int, struct proceventrec*, int);`
    - `void proc_logevent(struct proc*, int, int);`
    - `int proc_snapshot(struct procsnap*, int);`
    - `int proc_getprocinfo(int, struct procinfo*);`
    - `int proc_getsysinfo(struct sysinfo*);`

---

### 2. Kernel Core & Scheduling
- [trap.c](../trap.c)
  - In `trap()` timer interrupt handler (`T_IRQ0 + IRQ_TIMER`):
    - Added process CPU tick accounting: if `myproc() && myproc()->state == RUNNING`, increments `myproc()->total_ticks++` and updates `myproc()->last_cpu_tick = ticks`.

- [proc.c](../proc.c)
  - Added dedicated `historylock` spinlock and `historyseq` monotonic sequence counter initialized in `pinit()`.
  - Implemented `proc_logevent()` to append event records into per-process ring buffers.
  - Implemented `proc_history()` to copy bounded event records for a requested PID.
  - Implemented `proc_snapshot()` to copy active processes into a user buffer.
  - Implemented `is_descendant()` and `get_descendant_ticks()` to dynamically compute cumulative CPU runtime consumed across all active and reaped descendants in the process tree.
  - Implemented `proc_getprocinfo()` to retrieve detailed metadata for any live process.
  - Implemented `proc_getsysinfo()` to compute active, runnable/running, sleeping process counts and system uptime ticks.
  - Initialized timing fields (`ctime = ticks`, `last_cpu_tick = ticks`, `total_ticks = 0`, `descendant_ticks = 0`) in `allocproc()`.
  - Updated `p->last_cpu_tick = ticks` in `scheduler()` when a process transitions to `RUNNING`.
  - Accumulated child CPU execution time into `curproc->descendant_ticks += p->total_ticks + p->descendant_ticks` in `wait()` when reaping a zombie.
  - Instrumented lifecycle logging points in `allocproc()`, `fork()`, `sleep()`, `wakeup1()`, `kill()`, and `exit()`.

- [exec.c](../exec.c)
  - Added `proc_logevent(curproc, PROCEVENT_EXEC, 0)` on successful binary image load.

---

### 3. System Call Layer
- [syscall.h](../syscall.h)
  - Added syscall numbers:
    - `#define SYS_history 22`
    - `#define SYS_ps      23`
    - `#define SYS_getprocinfo 24`
    - `#define SYS_getsysinfo  25`

- [syscall.c](../syscall.c)
  - Declared `sys_history`, `sys_ps`, `sys_getprocinfo`, `sys_getsysinfo`.
  - Registered all four syscalls in the `syscalls[]` dispatch table.

- [sysproc.c](../sysproc.c)
  - Implemented `sys_history()`: argument validation via `argint`/`argptr`, kernel buffer fill, and `copyout()`.
  - Implemented `sys_ps()`: argument validation, snapshot collection, and `copyout()`.
  - Implemented `sys_getprocinfo()`: argument validation for PID and user pointer, kernel `proc_getprocinfo()` call, and `copyout()`.
  - Implemented `sys_getsysinfo()`: argument validation for user pointer, kernel `proc_getsysinfo()` call, and `copyout()`.

- [usys.S](../usys.S)
  - Added syscall entry points for `history`, `ps`, `getprocinfo`, and `getsysinfo`.

---

### 4. User Utilities & Tests
- [ps.c](../ps.c)
  - Updated user utility that integrates both features:
    - Calls `getsysinfo()` to print the system summary header (`Uptime`, `Active`, `Runnable`, `Sleeping`).
    - Calls `ps()` and `getprocinfo()` to print a detailed table (`PID`, `PPID`, `STATE`, `SIZE`, `CTIME`, `CPUTIME`, `DESCTIME`, `TOTTIME`, `LASTCPU`, `NAME`).
    - Supports optional PID argument `ps <pid>` to inspect full formatted metadata for a specific process including Total CPU Ticks.

- [history.c](../history.c)
  - User utility that invokes `history(pid, buf, HISTORY_MAX)` and formats the event history with sequence numbers, event names, and info values.

- [featuretest.c](../featuretest.c) (new)
  - Comprehensive test and visualization suite that:
    - Spawns a multi-level process tree (Root -> CPU/Memory/Sleep Children -> Grandchildren).
    - Tests `getsysinfo()` and `ps()` live snapshotting while all processes are executing concurrently.
    - Demonstrates dynamic memory growth (+16KB, +8KB heap via `sbrk()`) reflected in `ps` and `struct procinfo`.
    - Demonstrates live descendant CPU tree accumulation and post-reap accumulation.
    - Retrieves and displays per-process event histories via `history(pid)`.

- [Makefile](../Makefile)
  - Added `_history`, `_ps`, and `_featuretest` to `UPROGS`.

---

## Design Notes and Rationale
1. **Accurate Tree-Wide Descendant Accounting**: When child processes exit, their execution time (`total_ticks + descendant_ticks`) is accumulated into the parent's `descendant_ticks` upon `wait()`. When querying live processes, the kernel dynamically inspects any currently active descendant branches to provide an accurate total without double-counting.
2. **Sum of Own and Descendant Ticks**: `struct procinfo` explicitly provides `total_cpu_ticks` (`total_ticks + descendant_ticks`) so monitoring utilities can directly display total CPU consumption of the process tree.
3. **Bounded Memory & Safety**: Per-process event histories and snapshot buffers are strictly bounded (`HISTORY_MAX` and `PROCSNAP_MAX`) to avoid unbounded kernel memory consumption.
4. **Safe Kernel-to-User Transfer**: All syscalls collect data in kernel-space structures and transfer data safely via `copyout()`, strictly validating user-supplied memory buffers and preventing memory corruption.
5. **Dedicated History Spinlock**: Using a separate `historylock` decouples event logging operations from `ptable.lock`, reducing lock contention during logging hooks.
6. **Clear Code Tagging**: All modifications across the codebase are explicitly tagged with `// modified:` comments for transparency and diff reporting.

---

## Testing and Verification
- **Build**: `make clean && make` produces the bootable image and all user utilities without compiler warnings.
- **Run comprehensive test suite**:
  ```sh
  $ featuretest
  =======================================================
     XV6 PROCESS MONITORING & EVENT LOGGING TEST SUITE   
  =======================================================
  [*] Root Coordinator started with PID 3
  [*] Spawning multi-level Process Tree...
  [*] Process tree structure created:
      Root Coordinator (PID 3)
       |-- Child 1: CPU-Intensive (PID 4)
       |    |-- Grandchild 1A (Heavy CPU)
       |    `-- Grandchild 1B (Moderate CPU)
       |-- Child 2: Memory-Heavy (PID 5, +16KB Heap)
       |    `-- Grandchild 2A (+8KB Heap)
       `-- Child 3: Sleep/State-Switching (PID 8)
  ...
  [SUCCESS] Feature 1 (CPU/Memory/Descendant Accounting) & Feature 2 (Event History) Verified!
  ```
- **Inspect system and process table**:
  ```sh
  $ ps
  === System Summary ===
  Uptime: 510 ticks | Active: 3 | Runnable: 1 | Sleeping: 2
  ======================
  PID   PPID  STATE   SIZE    CTIME  CPUTIME DESCTIME TOTTIME LASTCPU NAME
  1     0     sleep   12288   0      4       79        83       7       init
  2     1     sleep   16384   7      3       78        81       508     sh
  5     2     run     16384   507    12      0         12       521     ps
  ```
- **Inspect individual process details**:
  ```sh
  $ ps 2
  Process Information (PID 2):
    Name:             sh
    PPID:             1
    State:            sleep 
    Size:             16384 bytes
    Creation Tick:    7
    CPU Ticks:        4
    Descendant Ticks: 96
    Total CPU Ticks:  100
    Last CPU Tick:    748
  ```
- **Inspect process event history**:
  ```sh
  $ history 1
  History for pid 1
  SEQ  EVENT    INFO
  32 wakeup -2146380800
  33 sleep -2146380800
  ...
  ```
- **Stress and stability testing**: `forktest` and `usertests` confirm that standard xv6 kernel functionality remains fully stable and correct.
